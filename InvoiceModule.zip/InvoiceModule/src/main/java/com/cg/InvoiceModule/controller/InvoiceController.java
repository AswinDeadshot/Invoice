package com.cg.InvoiceModule.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.InvoiceModule.bean.Invoice;
import com.cg.InvoiceModule.exception.InvoiceException;
import com.cg.InvoiceModule.service.IInvoiceService;



@RestController
public class InvoiceController {
	@Autowired
	IInvoiceService iiService;
	
	@RequestMapping("/products")
    public List<Invoice> getAllProducts()throws InvoiceException{


        return iiService.getAllProducts();
    }
//@RequestMapping(value="/product",method=RequestMethod.POST)  
//    
//    public List<Invoice> addProduct(@Valid@RequestBody Invoice pro)throws InvoiceException {
//        return iiService.addProduct(pro);
//	}
	
	@RequestMapping(value = "/{id}/invoice")
  	public List<Invoice> getInvoice(@PathVariable int id)throws InvoiceException {
  		return iiService.getInvoice(id);
  	}
  
  @RequestMapping(value = "/{id}/invoiceb")
  	public double getInvoiceb(@PathVariable int id)throws InvoiceException {
  		return iiService.getInvoiceb(id);
  	}

}
