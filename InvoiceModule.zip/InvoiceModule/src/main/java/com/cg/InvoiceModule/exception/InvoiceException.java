package com.cg.InvoiceModule.exception;

public class InvoiceException extends Exception{
	
	public InvoiceException()
    {
        super();
    }
    public InvoiceException(String msg)
    {
        super(msg);
    }

}
