package com.cg.InvoiceModule.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.InvoiceModule.bean.Invoice;
import com.cg.InvoiceModule.dao.IInvoiceDao;
import com.cg.InvoiceModule.exception.InvoiceException;



@Service
public class InvoiceService implements IInvoiceService{
	@Autowired
	IInvoiceDao iinvoicedao;
	
	
	public List<Invoice> getAllProducts()throws InvoiceException
	{
		try {  
              return iinvoicedao.findAll();
       }
		catch(Exception ex)
        {
        	throw new InvoiceException(ex.getMessage()+" No products available in the store "); 
        }
		
	}
	
	public List<Invoice> addProduct(Invoice pro)throws InvoiceException
	{
		try {
        iinvoicedao.save(pro);
        return iinvoicedao.findAll();
		}
		catch(Exception ex)
        {
        	throw new InvoiceException(ex.getMessage()+"  product is not able to add to the cart "); 
        }
		
		
    }

 
	
	public List<Invoice> getInvoice(int id)throws InvoiceException
	
	{

		try {
		return iinvoicedao.findAll(id);
		}
		catch(Exception ex)
        {
        	throw new InvoiceException(ex.getMessage()+" No product available with this customer id"+ id);
        }
	}

	public double getInvoiceb(int id)throws InvoiceException 
	{
		try {
	     
		return iinvoicedao.sum(id);
		}
		catch(Exception ex)
        {
        	throw new InvoiceException(ex.getMessage()+"Invoice is not generated"+ id);
        }
	}

}
