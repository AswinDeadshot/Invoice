package com.cg.InvoiceModule.bean;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Invoice {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public int inv_id;
	public int prod_id;
	public int cust_id;
	public String prod_name;
	public double prod_price;
	@JsonFormat(pattern="dd-MM-yyyy")
	private Date InvoiceDate;
	private double discounted_price;
	
	
	
	public double getDiscounted_price() {
		return discounted_price;
	}
	public void setDiscounted_price(double discounted_price) {
		this.discounted_price = discounted_price;
	}
	public int getInv_id() {
		return inv_id;
	}
	public void setInv_id(int inv_id) {
		this.inv_id = inv_id;
	}
	public int getProd_id() {
		return prod_id;
	}
	public void setProd_id(int prod_id) {
		this.prod_id = prod_id;
	}
	public int getCust_id() {
		return cust_id;
	}
	public void setCust_id(int cust_id) {
		this.cust_id = cust_id;
	}
	public String getProd_name() {
		return prod_name;
	}
	public void setProd_name(String prod_name) {
		this.prod_name = prod_name;
	}
	public double getProd_price() {
		return prod_price;
	}
	public void setProd_price(double prod_price) {
		this.prod_price = prod_price;
	}
	public Date getInvoiceDate() {
		return InvoiceDate;
	}
	public void setInvoiceDate(Date invoiceDate) {
		InvoiceDate = invoiceDate;
	}
	
	public Invoice(int inv_id, int prod_id, int cust_id, String prod_name, double prod_price, Date invoiceDate,
			double discounted_price) {
		super();
		this.inv_id = inv_id;
		this.prod_id = prod_id;
		this.cust_id = cust_id;
		this.prod_name = prod_name;
		this.prod_price = prod_price;
		InvoiceDate = invoiceDate;
		this.discounted_price = discounted_price;
	}
	public Invoice() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Invoice [inv_id=" + inv_id + ", prod_id=" + prod_id + ", cust_id=" + cust_id + ", prod_name="
				+ prod_name + ", prod_price=" + prod_price + ", InvoiceDate=" + InvoiceDate + ", discounted_price="
				+ discounted_price + "]";
	}
	
}
