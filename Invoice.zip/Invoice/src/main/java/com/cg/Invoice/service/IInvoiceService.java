package com.cg.Invoice.service;

import java.util.List;

import javax.validation.Valid;

import com.cg.Invoice.bean.Invoice;

public interface IInvoiceService {
	
	public List<Invoice> getInvoice(int id);
	public double getInvoiceb(int id);
	
	public List<Invoice> addProduct(@Valid Invoice pro);
	public List<Invoice> getAllProducts();
}
