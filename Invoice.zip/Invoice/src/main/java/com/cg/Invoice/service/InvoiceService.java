package com.cg.Invoice.service;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.Invoice.bean.Invoice;
import com.cg.Invoice.dao.IInvoiceDao;


@Service
public class InvoiceService implements IInvoiceService{
	
	@Autowired
	IInvoiceDao iinvoicedao;
	
	public List<Invoice> getAllProducts() {
        
        
            return iinvoicedao.findAll();
 }
 
	
	public List<Invoice> getInvoice(int id) {

		return iinvoicedao.findAll(id);
	}

	public double getInvoiceb(int id) {
		return iinvoicedao.sum(id);
	}


	public List<Invoice> addProduct(Invoice pro){
        iinvoicedao.save(pro);
        return iinvoicedao.findAll();
     }

}
