package com.cg.Invoice.bean;

public class Customer {

}
